package main

import (
	"awesomeProject/src/player"
)

/*
E:/GOPATH/huge.st1
E:/GOPATH/sy.st2
*/
func main() {

	var play player.Player
	play.PlayerInit()
	play.PlayerMenu()
}