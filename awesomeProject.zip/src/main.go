package main

import (
	"awesomeProject/src/player"
)

/*
E:/GOPATH/huge.st1
E:/GOPATH/sy.st2
*/
func main() {

	var play player.Player
	play.Player_init()
	for {
		choose := play.Player_menu()
		if choose == 4 {
			break;
		}
	}
}