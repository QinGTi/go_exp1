package song

import (
	"awesomeProject/src/tools"
	"fmt"
	"path"
	"strconv"
)

type Song struct {
	style 	string
	name 	string
	time 	int
	size 	int
	singer 	string
	album	string
	lrc		[]string
	all		[]string
}

func (s *Song) Read_song_file(file string) {
	//获取文件后缀
	s.style 	= path.Ext(file)
	//读取文件内容
	s.all		= tools.Read_file_line(file)
	//fmt.Println(s.all)
	s.name 		= s.all[0]
	s.time, _	= strconv.Atoi(s.all[1])
	s.size, _	= strconv.Atoi(s.all[2])
	s.singer	= s.all[3]
	s.album		= s.all[4]
	s.lrc		= s.all[5:]
}

func (s *Song) Run_lrc(suffer string) {
	for i, v := range s.lrc {
		tools.My_sleep(1)
		fmt.Printf("%d.%s", i, v)
		for j := 0; j < 5; j++ {
			fmt.Print(suffer)
		}
		fmt.Println()
	}
}

func (s *Song) Set_name() {
	fmt.Print("输入新名称:")
	r_name := tools.Read_string()
	s.name = r_name
}

func (s *Song) Set_time() {
	fmt.Print("输入新时长:")
	r_time := tools.Read_int()
	s.time = r_time
}

func (s *Song) Set_size() {
	fmt.Print("输入新大小:")
	r_size := tools.Read_int()
	s.time = r_size
}

func (s *Song) Set_singer() {
	fmt.Print("输入新歌手:")
	r_singer := tools.Read_string()
	s.singer = r_singer
}

func (s *Song) Set_album() {
	fmt.Print("输入新专辑:")
	r_album := tools.Read_string()
	s.album = r_album
}

func (s *Song) Get_style() string {
	return s.style
}

func (s *Song) Get_name() string {
	return s.name
}