package tools

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"os/exec"
	"runtime"
	"strconv"
	"strings"
	"time"
)

var inputReader = bufio.NewReader(os.Stdin)

func Read_int() int {
	input, _ := inputReader.ReadString('\n')
	Filter_str(&input)
	r_int, _ := strconv.Atoi(input)
	return r_int
}

func Read_string() string {
	input, _ := inputReader.ReadString('\n')
	Filter_str(&input)
	r_string := input
	return r_string
}

func Read_file_line(file_name string) ([]string) {
	f, err := os.Open(file_name)
	if err != nil {
		return nil
	}
	defer f.Close()
	buf := bufio.NewReader(f)
	var result []string
	for {
		line, err := buf.ReadString('\n')
		Filter_str(&line)
		//fmt.Println(line)
		if err != nil {
			if err == io.EOF {
				return result
			}
			return nil
		}
		result = append(result, line)
	}
	return result
}

func Split(s rune) bool {
	if s == '-' {
		return true
	} else {
		return false
	}
}

func Read_map_file(file_name string) map[string]string {
	fmt.Println("Loading    .\\"+file_name)
	m := make(map[string]string)
	var buf []string = Read_file_line(file_name)
	for _, v := range buf {
		Filter_str(&v)
		var tmp []string = strings.FieldsFunc(v, Split)
		m[tmp[0]] = tmp[1]
	}
	return m
}

func Write_map_file(m map[string]string, file_name string) {
	f, _ := os.Create(file_name)
	defer f.Close()
	buf := bufio.NewWriter(f)
	for k, v := range m {
		line := fmt.Sprintf("%s-%s", k, v)
		fmt.Fprintln(buf, line)
	}
	buf.Flush()
}

func Path_exist(path string) bool {
	_, err := os.Stat(path)
	if err != nil && os.IsNotExist(err) {
		return false
	}
	return true
}

func My_sleep(x int) {
	time.Sleep(time.Duration(x)*time.Second)
}

func My_pause() {
	fmt.Println("按任意键继续...")
	var tmp string
	fmt.Scanf("%s", tmp)
}

func Clr_screen () {
	choose := runtime.GOOS
	if  choose == "linux"{
		cmd := exec.Command("clear")
		cmd.Stdout = os.Stdout
		cmd.Run()
	} else if choose == "windows" {
		cmd := exec.Command("cmd", "/c", "cls")
		cmd.Stdout = os.Stdout
		cmd.Run()
	}
}

func Filter_str(str *string) {
	(*str) = strings.Replace((*str),"\r", "", -1)
	(*str) = strings.Replace((*str),"\n", "", -1)
}
