package player

import (
	"awesomeProject/src/song"
	"awesomeProject/src/tools"
	"fmt"
)

type Player struct {
	song_list 	map[string]string
	remov_list  map[string]string
	suffer_list map[string]string
}

//播放器函数
//播放器大函数
func (p *Player) Player_init() {
	fmt.Println("init")
	p.song_list 	= tools.Read_map_file("song_list.txt")
	p.remov_list 	= make(map[string]string)
	p.suffer_list	= make(map[string]string)
	p.suffer_list[".st1"] = "!"
	p.suffer_list[".st2"] = "@"
	p.suffer_list[".st3"] = "#"
	p.suffer_list[".st4"] = "$"
	p.suffer_list[".st5"] = "%"
}

func (p Player) Player_menu() int {
	tools.Clr_screen()
	fmt.Println("1.管理歌曲")
	fmt.Println("2.播放歌曲")
	fmt.Println("3.回收站")
	fmt.Println("4.退出")
	fmt.Print("输入选择序号：")
	choose := tools.Read_int()
	switch choose {
	case 1:
		p.Player_ctrl()
	case 2:
		p.Player_run()
	case 3:
		p.Player_recycle()
	case 4:
		p.Player_quit()
	}
	tools.My_pause()
	return choose
}

func (p *Player) Player_ctrl() {
	tools.Clr_screen()
	fmt.Println("1.添加歌曲")
	fmt.Println("2.删除歌曲")
	fmt.Println("3.修改歌曲")
	fmt.Println("4.查找歌曲")
	fmt.Println("5.歌曲列表")
	fmt.Print("输入选择序号：")
	choose := tools.Read_int()
	switch choose {
	case 1:
		p.Add_song()
	case 2:
		p.Del_song()
	case 3:
		p.Rev_song()
	case 4:
		p.Fnd_song()
	case 5:
		p.Show_music_list()
	}
}

func (p *Player) Player_run() {
	if len(p.song_list) == 0 {
		fmt.Println("播放列表为空")
		return
	}
	p.Show_music_list()
	fmt.Print("输入待播放歌曲名:")
	choose := tools.Read_string()
	_, ok := p.song_list[choose]
	if ok == false {
		fmt.Println("歌名不存在")
		return
	}
	var tmp song.Song
	tmp.Read_song_file(p.song_list[choose])
	fmt.Println(tmp.Get_style())
	tmp.Run_lrc(p.suffer_list[tmp.Get_style()])
}

func (p *Player) Player_recycle() {
	if len(p.remov_list) == 0 {
		fmt.Println("回收站为空")
		return
	}
	p.Show_remov_list()
	fmt.Print("是否要恢复歌曲[yes/no]:")
	choose := tools.Read_string()
	if choose == "yes" {
		fmt.Print("输入待恢复歌曲名:")
		choose2 := tools.Read_string()
		_, ok := p.remov_list[choose2]
		if ok == false {
			fmt.Println("歌名不存在")
			return
		}
		p.song_list[choose2] = p.remov_list[choose2]
		delete(p.remov_list, choose2)
		fmt.Println("恢复成功")
	}
}

func (p *Player) Player_quit() {
	tools.Clr_screen()
	tools.Write_map_file(p.song_list, "song_list.txt")
	fmt.Println("信息保存完毕")
}

//播放器小函数

func (p *Player) Add_song() {
	tools.Clr_screen()
	fmt.Print("输入歌曲路径:")
	song_path := tools.Read_string()
	if tools.Path_exist(song_path) == false{
		fmt.Println("路径不存在")
		return
	}
	var tmp song.Song
	tmp.Read_song_file(song_path)
	p.song_list[tmp.Get_name()] = song_path
	fmt.Println("添加成功")
}

func (p *Player) Del_song() {
	p.Show_music_list()
	fmt.Print("输入待删除歌曲名：")
	del_name := tools.Read_string()
	_, ok := p.song_list[del_name]
	if ok == false {
		fmt.Println("歌名不存在")
		return
	}
	p.remov_list[del_name] = p.song_list[del_name]
	delete(p.song_list, del_name)
	fmt.Println("删除成功")
}

func (p *Player) Rev_song() {
	p.Show_music_list()
	fmt.Print("输入待修改歌名:")
	rev_name := tools.Read_string()
	_, ok := p.song_list[rev_name]
	if ok == false {
		fmt.Println("歌名不存在")
		return
	}
	var tmp song.Song
	tools.Clr_screen()
	tmp.Read_song_file(p.song_list[rev_name])
	fmt.Println("可修改属性如下")
	fmt.Println("1.名称")
	fmt.Println("2.时长")
	fmt.Println("3.大小")
	fmt.Println("4.歌手")
	fmt.Println("5.专辑")
	fmt.Print("输入待修改属性：")
	choose := tools.Read_int()
	if choose > 5 && choose < 1 {
		fmt.Println("输入有误")
		return
	}
	switch choose {
	case 1:
		tmp.Set_name()
	case 2:
		tmp.Set_time()
	case 3:
		tmp.Set_size()
	case 4:
		tmp.Set_singer()
	case 5:
		tmp.Set_album()
	}
	fmt.Println("修改完毕")
}

func (p *Player) Fnd_song() {
	tools.Clr_screen()
	fmt.Print("输入待查找歌名:")
	choose := tools.Read_string()
	_, ok := p.song_list[choose]
	if ok {
		fmt.Println("查找成功")
	} else {
		fmt.Println("查找失败")
	}
}

func (p *Player) Show_music_list() {
	tools.Clr_screen()
	fmt.Println("歌曲列表如下")
	i := 0
	for x := range p.song_list {
		i++
		fmt.Printf("%d.%s\n", i, x)
	}
}

func (p *Player) Show_remov_list() {
	tools.Clr_screen()
	fmt.Println("回收站信息")
	i := 0
	for x := range p.remov_list {
		i++
		fmt.Printf("%d.%s\n", i, x)
	}
}
